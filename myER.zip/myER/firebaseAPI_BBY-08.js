
const firebaseConfig = {
    apiKey: "AIzaSyBXMuaKiskDtZkfK2bJ66Qr28HoAX34n6g",
    authDomain: "comp1800-bby08.firebaseapp.com",
    projectId: "comp1800-bby08",
    storageBucket: "comp1800-bby08.appspot.com",
    messagingSenderId: "590388679901",
    appId: "1:590388679901:web:1a07abcb51e37b9c6c7734"
  };
  
  // Initialize Firebase
  const app = firebase.initializeApp(firebaseConfig);
  const db = firebase.firestore();
    